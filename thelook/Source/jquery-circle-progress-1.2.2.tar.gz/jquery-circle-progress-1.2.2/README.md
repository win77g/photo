jquery-circle-progress
======================

[![Build status](https://travis-ci.org/kottenator/jquery-circle-progress.svg?branch=master)](https://travis-ci.org/kottenator/jquery-circle-progress)
[![Bower version](https://img.shields.io/bower/v/jquery-circle-progress.svg?maxAge=2592000)](https://bower.io/search/?q=jquery-circle-progress)
[![NPM version](https://img.shields.io/npm/v/jquery-circle-progress.svg?maxAge=2592000)](https://www.npmjs.com/package/jquery-circle-progress)

jQuery Plugin to draw animated circular progress bars like this:

![](http://i.imgur.com/zV5VUQG.png)

Check out [more examples](http://kottenator.github.io/jquery-circle-progress/)! Or maybe the crazy [one](http://jsbin.com/vatuza/5/)?

Install
-------

Make your choice:

* Download [latest GitHub release](https://github.com/kottenator/jquery-circle-progress/releases)
* `bower install jquery-circle-progress`
* `npm install jquery-circle-progress`

Usage
-----

```html
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script src="jquery-circle-progress/dist/circle-progress.js"></script>

<div id="circle"></div>

<script>
  $('#circle').circleProgress({
    value: 0.75,
    size: 80,
    fill: {
      gradient: ["red", "orange"]
    }
  });
</script>
```

If you use AMD or CommonJS with some JS bundler - see the [UMD section](#umd) below.

Options
-------

Specify options like in example above.

| Option | Description |
| ---- | ---- |
| **value** | This is the only required option. It should be from `0.0` to `1.0` <br> Default: `0` 101     T7
* | Tpm/ | TSoftwarrogres / canvasmplepixelsefault: `0` 101 10    T7
*donsAn.coTpmInirtionan.coT(fonJ     | Th)efault: `0` 101 -Math.PI   T7
re](htoTpmRe](htoTd circ ---ociatrcnimatefault: `0` 101 false   T7
![]ckns li| Wid JSSoftwartrc. Byn t`0` 1 it's autoirc ceryy calrogrculaasm1/yslSof`* | `r -te AMDhe n](thoice: [l numbe tfault: `0` 101 "auto"   T7
lineCapi| Arcnline cap01 " -tt"`,1 "ro- s"  onJ "squto d`the[reestampl://github.de](loion.moz   attenaen-US/tats/Web/API/CanvasRenderditCoreext2D.lineCap)efault: `0` 101 " -tt"`T7

    is tartrc

    onsfig. YAMDhe n]optionsnext: efaul-1 "#ff1e41"`efaul-1 { onlor: "#ff1e41" }`efaul-1 { onlor: 'rgba(255, 255, 255, .3)' }`efaul-1 { t: ["red", "orange"
  ennge"b Th"] }`efaul-1 { t: ["red",  "orange.2],, "
  ennge.3],, "b Th"ge.8]] }`efaul-1 { t: ["red",  ... ],,t: ["redAn.co: Math.PI / 4 }`efaul-1 { t: ["red",  ... ],,t: ["redDtio#umd)", x0, y0, x1, y1] }`efaul-1 { cire_js"i.imgur.com/zV5VUQGpT0i89vChec" }`faul-1 { cire_jscire_
----nl b}`faul-1 { onlor: "limh"gecire_js"i.imgur.com/zV5VUQGpT0i89vChec" }`efault: `0` 101 { t: ["red", "#3aeabbnge"#fdd250"] }`e T7
emptyF    isCnlorSSoftwar"empty"rtrc. Ouirea onlor

    sups ofulabnsnotefault: `0` 101 "rgba(0, 0, 0, .1)"   T7
d circ ---| A circ ---onsfig. S[UM[Plugin d circ --://kottenam/a.min.js"x/lib circu/).efaultYAMDhe nalson](thie fol false  fault: `0` 101 { duraumd)",1htt, * `ditjs"rogress({
    E `b" }`e fault`"rogress({
    E `b"` *onlj0roea * `b-in-re -cubic * `dit*  T7
d circ --SdonsV| Thripti`0` 1 d circ ---*donss atto `1.0ociaends att]optioiula` | Th`. Let's ceryermissdtio#u d circ --oulse AMDwane folmr chre](htod d circ ---twane AMDbe from](th`d circ --SdonsV| Th.0` <br> D. AlsonyAMDhe n]optionsson otwar  | Th0.0` to `1.0` <br> Default: `0` 101  > DT7
 jqertModhripCanvasmplqert ---modh: append onJprepend ie infollowipto ne )
*on f?efault: `0` 101 "prepend"   T
F0` t](https<br>1.3`nyAMDcann]optionsson onsfig. It shaasmHTML `data-.0ot, sublitiold w    work *quireerebnir*gec.e. afttpllowiwidg(thisebnirod yAMDhe nupdatampss s.jpert ubstuirevia `Progress({
    va/*...*/})` method. `data-.0ot, sublis w    uded     dtioAlso, oo the  like in exam`"
   "  onJ "d circ --"  be from `0 | iddleON (ociadon't fong(th
| -teHTML-ionm/aeck:ml
<script scr</sclasse"></div></sdata- | Th="0.9></sdata-* | ="60></sdata-![]ckns l="20></sdata-d circ ---*dons- | Th="r> ></sdata-
   =" gradi&quot;onlor&quot;:i&quot;rgba(0, 0, 0, .3)&quot;,gradi&quot;cire_&quot;:i&quot;i.imgur.com/zV5VUQGpT0i89vChec&quot;</sc></sdata-re](hto="trTh"


<scrip you Ev    

Specify| Ev   ription |
| ---- Ha see t- | ---- |
| **va
| **value`progresbnirod` is riggeion. rebnir onJresbnir. is`fun#umd)(ev   )`:efaul-1 ev   `thePlugin ev   rilue`progresd circ ---*dons` is riggeion. rcUMD sed circ ---waredons dt is`fun#umd)(ev   )`:efaul-1 ev   `thePlugin ev   rilue`progresd circ ---s`

Usage is riggeion. reeach [d circ ---t]ck//kottenam/a.min.js"x/lib circu/#step)t is`fun#umd)(ev   ,ed circ --s({
    , stepV| Th)`:efaul-1 ev   `thePlugin ev   rfaul-1 d circ --s({
    `the.0` to `1.0` <br> Defaul-1 stepV| Th`thecuro ne step 0.75,
 .0` to `1.0` <b | Th`rilue`progresd circ ---end` is riggeion. rcUMD sed circ ---warfito do t is`fun#umd)(ev   )`:efaul-1 ev   `thePlugin ev   ril
Browqers sups of-

Speciiiiiiiiiibove cuerrain  ors `<canvas>` w[]ch-wareups ofulabnseryemodhrn browqers *(ng withoutmobicoTbrowqers)*
ociaIreern(thExplore t9+ ([Can I Us://jsbin.ccani or"x/li#?q=jqu=canvas))tiol hav  't iove.on fod d y fallback / poly
    fonJuneups ofulabrowqers yet
*(n.e. fonJIreern(thExplore t80ociaoldhr / miscTbrowqers)*tiotio
iiiboID or ctiontempgrcu fonJPlugin po dra://github.com/kottenalowjsalow/blob/d31bb6ee7098715e019f52bdfe27b3e4bfd2b97e/tempgrcuy/3.1.0/to dra.js) w[]ch-tenbinenly r[UMD houswnloaworkarfitut res _browqer:
    -s_loaworkarfitut res Aio
oaworkarfitut res S with s

### Browqer:
    -sml
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script src="jquery-circle-progress/dist/circle-progress.js"></script>

<div i>
  $('#circle').circleProgress({
    value: 0.75,
    size:cript>
```

If you ### Aio

Assumhoutthate AMDhav  `circle`,1 circle-progress`

Usage0ocia`d optiojge0is<buery/`sdtio#uory:ml
<script src="https:/uery/d optiojg/d optioscript>

<div i>
  $('#cird optiojg.onsfigvalue: paths   gradien'circle': 'uery/3.1.0/jrcle-circle', //n'circle' path-ward option.-n'circle-progress`

Usag'rd optiosebtgradien'circle-progress`

Usag': 'uery/3.1.0/-progress/dist/circle-progress.js"></' //ns permissone-warfonJoice:
onv  "rece  });
</scripird optiojg(['circle', 'circle-progress`

Usag'],,fun#umd)($)  gradicle').circleProgress({
    value: : 0.75,
    s  });
ripircript>
```

If you YAMDcann[onsfigure R optioJS//jsbin.cd optiojg.tenatats/m/a.crip)aasm AMDwstribj0roemr ch`'circle'`sdependrecred achablitio### S with s

 yojs
//n
```

scr
d optio('circle-progress`

Usag'ripvar $ = d optio('circle'ripcle').circleProgress({
    value0.75,
    s crip you  yosh
 bun-js- - see t<n
```

scr >n
```

s - seescr
 you  yocript src="https:/
```

s - seescript>

<div i you YAMDcannutoTd ydler - see t([Web/jqu://www.npmjeb/jqu.io/jquery-), [Browqerion//jsbin.cbrowqerion.tena), etc).-nnot]optioic onsfigurrc ---d optiontioAPI
iiibo### Get/](th0.75,

G(thie:

 yojs
cle.).circleProgress({
    vae0.75,
   5rcripvar  | Th0= cle.).circleProgress({
    v' | Th'ri //n  5f you ud w    returights
*first*hieem's  | Th0(bns*first*hI meannwwane`cle.).circlePlength->= 1`)ti*ud workartuireifllowiwidg(thisealreesyebnirod. Raiors annerrorSStwarwste*tioS(thie:

 yojs
cle.).circleProgress({
    v' | Th',    sri //n](th0.75,0` <   s &ed circuftwarrh    f you ud w    updatam*all*opieo#ull
ceems  | Th0ociat circuftwarrh    . ud does 't *ionraw*llowiwidg(th- ie updatanly re | Th0&ed circusftwarrh    s.
ForS above., ie he nbh0oc AJAX ateshoutindicuery, w[]ch-be wsftwarateshouts.js"></sbo### Get `<canvas>`

 yojs
cle.).circleProgress({
    vae0.75,
   5rcripvar canvasm= cle.).circleProgress({
    v'widg(t'rip you ud w    returights
*first*hieem's `<canvas>` (bns*first*hI meannwwane`cle.).circlePlength->= 1`)ti*ud workartuireifllowiwidg(thisealreesyebnirod. Raiors annerrorSStwarwste*tio### Get `Cogress({
    `l jqueece 
 yojs
var  jqueecem= cle').circlePdata('progress`

Usag'rip you ### RonrawS acleditiorogre

 yojs
cle').circleProgress({
    vae0.75,
   5,{
       onlor: ']
    ' }}ripcle').circleProgress({
    v'ionraw'ri //nutoTcuro ne onsfigurrc ---ociaionrawpcle').circleProgress({
    vri //naliaarfonJ'ionraw'
cle').circleProgress({
    vae0,
   150rcri //n](thnew
* | Tociaionrawp you *ud workartuireifllowiwidg(thisealreesyebnirod. Raiors annerrorSStwarwste*tio### Ch    n t`0` 1  like i

 yojs
cProgress({
    . t`0` 1s.* | T= 50ip you FAQ
iiibo<dl i>dt>How0` <edonsMD sed circ ---tuirewwanetwarrogres appee thin browqer's  iew
(---*crollaeck?i>dd>Heurnis <a  r[f://ajax.gocom/kottenator/jquery-circle-progress/releaseissuuy/8">my s.jpotod soluc --</a>.i>dt>How0` <mr chtwar* | Tfl acbli?i>dd>E.g. fonJleape iiv n tsign,nyAMDcanndo ie <a  r[f://ajax.gocom/kottenator/jquery-circle-progress/releaseissuuy/17">Softwarng conditiway</a>.i>dt>WhateiflIhnell
ce0` <rurebn IE8?i>dd>Theurnis notfull-feature eups of fonJIE8 (actueryy,lIhdid 't iolp.on fJIE8 eups of ateery). B-te AMDhe nng con <a  r[f://ajax.gocom/kottenator/jquery-circle-progress/releaseissuuy/35">my io#895a8drc --:</a>.i>dt>How0` <stopMD sed circ --?i>dd>Heurnis <a  r[f://ajax.gocom/kottenator/jquery-circle-progress/releaseissuuy/37">whate AMDcanndo</a>.i>dt>Can I ha see "click" ev   ?i>dd>It's noe inftwar"core"r -te AMDcannutoT<a  r[f://aja.gooutpu
scr/vatuza/fet op/5">my  above.
of mouto/touch-ev   s ha sedit</a>.i>dt>Me nITcustom | Ttwar*hapeS bune w?i>dd>It's a bce0"n, iky"r -tepotscbli. Heurnis <a  r[f://ajax.gocom/kottenator/jquery-circle-progress/releasewiki/Custom-la AMts">my littlightllo#umd)</a>.i>/dl i
De](loion f
ciiiiiiiiiibo### 
-------  yosh
com clone-com@com/kotten:tor/jquery-circle-progress.svg?bracom
tall jqueryp you ### Mmergeu YAMDnell
 coppdatam`rcle-progress.js"></s></scr` afttplson oh    n` <brcle-progress.js"></scr`:
   yosh
tallrurebatus-></f you use AM'ionutditione-of JetBra jq IDEsh-  AMDcannonsfigure a FicoTWatcheu. ud's alsonpotscbli  copy,S bundCLI  coln exam[Watchmaa://github.faceboou.io/jquery-watchmaa/)tio### T:
    yosh
tallv:
   you SauceLabs:   yosh
DISPLAYSAUCE_USERNAME=...
DISPLAYSAUCE_ACCESS_KEY=...
DISPLAYBUILD_NUMBER=...
tallv:
  -- karma-saucelabs.onsfscr
 you ### Batus]tatsbove cAPI]tats furnnoe nts/let  yetr -te AMDcannbatusTtwam:
  yosh
tallrurebatus-tatsb you ve y w    udegenerrculais<btats/m/a/`.u ### Ro
* `bhnew
](httpsnloafinali| Ttwarcodeloappdatamy re (https<is<b/jqueryscron`,1 o/searcron`0ocia`rcle-progress.js"></scr`]tatstrditloappdatam></bute,:nstallrurebatus-></`loappdatambtats/index.crip`theedik followiGitHub ute,e (https<_(w[]ch-does 't  acle yet)_loapushftwarrh    sn` <b](http` masterloas)
* `b. reersio:bj0roecreete a Gce0`ag (e.g.):nsgce0`ag vEADM3 &&-comapushf--`agpm ins)
* `b. rerelease- addns)
* `b.noe sn` <twarGce0`ag ins)
* `b. reNPM:nstall, distr`,1 -tebh0oTHE  secsec> Oecema /jquerynis , distrula res a-cov   nam Tocia (https,tthate]optioic nam Tocia (https-tenbinrc ---oannne](hebh0utod dga jthe[siontats://github.datscom/packagecli/, 